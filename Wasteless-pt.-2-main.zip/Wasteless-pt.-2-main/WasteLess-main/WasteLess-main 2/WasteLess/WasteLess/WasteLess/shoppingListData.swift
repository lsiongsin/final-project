//
//  shoppingListData.swift
//  WasteLess
//
//  Created by Scholar on 8/17/22.
//

import Foundation

//class shoppingListData {
//    static var dairyItem = ""
//
//    displayTextFirstVC.text = ShoppingList.dairyItem
//
//}
